/*--------------------------------------------------------------
 * Written by: Essey Mehari
 * For: CMPT 201, X02L, Lab Exercise E2
 * Lab instructor: Hanan Saleh
 * Lecture instructor: Philip Mees
 * Description: Reads a square matrix, prints main diagonal,
 *  computes secondary diagonal product, calculates and displays
 *  column sums using 5 helper functions.
 * Filename: lab4E2.c
 --------------------------------------------------------------*/

#include <stdio.h>

#define MAX_SIZE 5

// Reads user input into the matrix
void fillMatrix(int matrix[MAX_SIZE][MAX_SIZE], int size) {
    int row, col;
    for (row = 0; row < size; row++) {
        for (col = 0; col < size; col++) {
            scanf("%d", &matrix[row][col]);
        }
    }
}

// Prints the main diagonal of the matrix
void printMainDiagonal(int matrix[MAX_SIZE][MAX_SIZE], int size) {
    int i;
    printf("The elements on the main diagonal are: ");
    for (i = 0; i < size; i++) {
        printf("%d ", matrix[i][i]);
    }
    printf("\n");
}

// Returns the product of the secondary (anti) diagonal
int secondaryDiagonalProduct(int matrix[MAX_SIZE][MAX_SIZE], int size) {
    int i, product = 1;
    for (i = 0; i < size; i++) {
        product *= matrix[i][size - 1 - i];
    }
    return product;
}

// Computes and stores column sums in colSum array
void computeColumnSums(int matrix[MAX_SIZE][MAX_SIZE], int size, int colSum[MAX_SIZE]) {
    int row, col;
    for (col = 0; col < size; col++) {
        colSum[col] = 0;
        for (row = 0; row < size; row++) {
            colSum[col] += matrix[row][col];
        }
    }
}

// Prints the contents of the colSum array
void printColumnSums(int colSum[MAX_SIZE], int size) {
    int i;
    for (i = 0; i < size; i++) {
        printf("The sum of elements in column %d is: %d\n", i + 1, colSum[i]);
    }
}

// Main function
int main() {
    int matrix[MAX_SIZE][MAX_SIZE];
    int colSum[MAX_SIZE];
    int size, product;

    printf("Enter the size of the square matrix (max 5): ");
    scanf("%d", &size);

    if (size < 1 || size > MAX_SIZE) {
        printf("Invalid size. Must be between 1 and 5.\n");
        return 1;
    }

    printf("Enter the matrix values row by row:\n");
    fillMatrix(matrix, size);

    printMainDiagonal(matrix, size);

    product = secondaryDiagonalProduct(matrix, size);
    printf("The product of the elements on the secondary diagonal is: %d\n", product);

    computeColumnSums(matrix, size, colSum);
    printColumnSums(colSum, size);

    return 0;
}
