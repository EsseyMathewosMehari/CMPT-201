/*--------------------------------------------------------------
 * Written by: Essey Mehari
 * For: CMPT 201, X02L, Lab Exercise E1
 * Lab instructor: Hanan Saleh
 * Lecture instructor: Philip Mees
 * Description: Prompts user for a string and a character,
 * removes all instances of that character from the string,
 * prints the modified string and how many times it occurred.
 * Filename: lab4E1.c
 --------------------------------------------------------------*/

#include <stdio.h>

#define MAX_LENGTH 26 // 25 characters + '\0'

int main()
{
    char str[MAX_LENGTH];  // The string array (max 25 + null terminator)
    char ch;               // Character to be removed
    char c;                // Temporary input char
    int i = 0, j = 0, count = 0;

    printf("Enter a string (max length 25): ");

    // Read up to 25 characters manually using getchar()
    while (i < MAX_LENGTH - 1 && (c = getchar()) != '\n') {
        str[i] = c;
        i++;
    }
    str[i] = '\0'; // Null-terminate the string

    // Prompt for character to remove
    printf("Enter a character: ");
    scanf(" %c", &ch); // Space before %c skips leftover newline

    // Remove character from string and count its occurrences
    i = 0;
    while (str[i] != '\0') {
        if (str[i] == ch) {
            count++; // Don't copy this char
        } else {
            str[j] = str[i]; // Keep this char
            j++;
        }
        i++;
    }
    str[j] = '\0'; // End modified string

    // Output results
    printf("The string: %s\n", str);
    printf("Character %c occurred %d %s.\n", ch, count, count == 1 ? "time" : "times");

    return 0;
}
