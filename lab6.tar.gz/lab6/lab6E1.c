/*--------------------------------------------------------------
 * Written by: Essey Mehari
 * For: CMPT 201, X02L, Lab Exercise 6
 * Lab instructor: Hanan Saleh
 * Lecture instructor: Philip Mees
 * Description: This is the main test file for our linked list.
 * It builds a list of fruits, adds to the front and back,
 * deletes some, and finally destroys the entire list.
 * Filename: lab6E1.c
 *-------------------------------------------------------------*/

#include "link.h"
#include <stdio.h>
#include <string.h>

/*******************************************************************************************
 * Purpose:
 *   This main program runs a test of all the linked list functions.
 *   It starts by creating a list with one string, then adds more
 *   to the front and back. It deletes specific items and finally
 *   frees all memory by destroying the list.
 * Parameters:
 *   none
 * Returns:
 *   int (0 when program finishes successfully)
 *******************************************************************************************/
int main(void) {
    struct node *myList;         // This will point to the head of our list
    char add[15] = "apple";

    // Create the list with the first item
    myList = createList(add);

    // Display list contents
    printList(myList);
    printf("\n");

    // Add more fruit to the front of the list
    strcpy(add, "pear");
    addFront(add, &myList);

    strcpy(add, "grape");
    addFront(add, &myList);

    // Add fruit to the end of the list
    strcpy(add, "peach");
    addRear(add, &myList);

    strcpy(add, "orange");
    addRear(add, &myList);

    // Display list after additions
    printList(myList);
    printf("\n");

    // Delete some items from different parts of the list
    deleteNode("pear", &myList);
    deleteNode("orange", &myList);
    deleteNode("apple", &myList);

    // Display list after deletions
    printList(myList);
    printf("\n");

    // Clean up and free memory
    destroy(&myList);

    // Print again to confirm list is gone
    printList(myList);

    return 0;
}
