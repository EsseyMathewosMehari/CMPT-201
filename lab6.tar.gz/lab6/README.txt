Fix 1:
Line detected: In function addRear, the for loop that traverses to the last node
Debugger commands: Used gdb to run step-by-step and print pointer values with `print p` to see if p was NULL or not
Hypothesis: The list might be empty or p could be NULL, causing a crash when accessing p->next
How I fixed it: Added a check if the list is empty , then made *list = new node directly. 

Fix 2:
Line detected: In deleteNode, variable cur was used without initialization
Debugger commands: Used gdb and saw that cur had garbage value causing segmentation fault when trying to access cur->data
Hypothesis: The pointer cur was not initialized to *list, so it pointed randomly causing crash
How I fixed it: Initialized cur to *list at the start of deleteNode.

Fix 3:
Line detected: In createList, string data was not allocated memory before strcpy
Debugger commands: Used valgrind to detect invalid memory writes when strcpy was called
Hypothesis: Since create->data was not malloc’d, strcpy wrote to unallocated memory causing undefined behavior
How I fixed it: Allocated memory for create->data with malloc before copying string into it.
