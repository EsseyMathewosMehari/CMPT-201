/*--------------------------------------------------------------
 * Written by: Essey Mehari
 * For: CMPT 201, X02L, Lab Exercise 6
 * Lab instructor: Hanan Saleh
 * Lecture instructor: Philip Mees
 * Description: This file contains the function definitions for
 * working with a basic singly linked list. The list stores strings,
 * and you can add, delete, print, or destroy it.
 * Filename: link.c
 *-------------------------------------------------------------*/

#include <stdio.h>
#include "link.h"
#include <string.h>
#include <stdlib.h>

#define MAX_STR_LEN 100  // fixed max size for strings (no dynamic resizing)

/*******************************************************************************************
 * Purpose:
 *   Goes through each node in the list and prints out the string it holds.
 *   If the list is empty, it lets the user know.
 * Parameters:
 *    list: pointer to the first node in the linked list
 * Returns:
 *    void (nothing)
 *******************************************************************************************/
void printList(struct node *list) {
    int count = 1;

    while (list != NULL) {
        printf("Element number: %d is %s\n", count, list->data);
        list = list->next;
        count++;
    }

    if (count == 1) {
        printf("List is empty\n");
    }
}

/*******************************************************************************************
 * Purpose:
 *   Creates the first node of a linked list and initializes it with the given string.
 * Parameters:
 *    firstE: the string to store in the new node 
 * Returns:
 *    A pointer to the newly created node (head of the list)
 *******************************************************************************************/
struct node *createList(char *firstE) {
    struct node *newNode = malloc(sizeof(struct node));
    newNode->data = malloc(MAX_STR_LEN);
    strcpy(newNode->data, firstE);
    newNode->next = NULL;
    return newNode;
}

/*******************************************************************************************
 * Purpose:
 *   Adds a new node to the beginning of the list, pushing the old head down one position.
 * Parameters:
 *    value: the string to store in the new node
 *    list: a pointer to the pointer of the list’s head
 * Returns:
 *    void (nothing)
 *******************************************************************************************/
void addFront(char *value, struct node **list) {
    struct node *newNode = malloc(sizeof(struct node));
    newNode->data = malloc(MAX_STR_LEN);
    strcpy(newNode->data, value);
    newNode->next = *list;
    *list = newNode;
}

/*******************************************************************************************
 * Purpose:
 *   Adds a new node to the end of the list.
 * Parameters:
 *    value: the string to store in the new node
 *    list: a pointer to the pointer of the list’s head
 * Returns:
 *    void (nothing)
 *******************************************************************************************/
void addRear(char *value, struct node **list) {
    struct node *newNode = malloc(sizeof(struct node));
    newNode->data = malloc(MAX_STR_LEN);
    strcpy(newNode->data, value);
    newNode->next = NULL;

    struct node *p = *list;

    while (p->next != NULL) {
        p = p->next;
    }

    p->next = newNode;
}

/*******************************************************************************************
 * Purpose:
 *   Removes the first node in the list that contains a matching string.
 * Parameters:
 *    value: the string to search for
 *    list: a pointer to the pointer of the list’s head
 * Returns:
 *    void (nothing)
 *******************************************************************************************/
void deleteNode(char *value, struct node **list) {
    struct node *prev = NULL;
    struct node *cur = *list;

    while (cur != NULL && strcmp(cur->data, value) != 0) {
        prev = cur;
        cur = cur->next;
    }

    if (cur == NULL) return;

    if (prev == NULL) {
        *list = cur->next;
    } else {
        prev->next = cur->next;
    }

    free(cur->data);
    free(cur);
}

/*******************************************************************************************
 * Purpose:
 *   Frees all the nodes in the list to release memory and avoid leaks.
 * Parameters:
 *    list: a pointer to the pointer of the list’s head
 * Returns:
 *    void (nothing)
 *******************************************************************************************/
void destroy(struct node **list) {
    struct node *cur = *list;
    while (cur != NULL) {
        struct node *next = cur->next;
        free(cur->data);
        free(cur);
        cur = next;
    }
    *list = NULL;
}
