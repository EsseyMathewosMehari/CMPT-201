/*--------------------------------------------------------------
 * Written by: Essey Mehari
 * For: CMPT 201, X02L, Lab Exercise 6
 * Lab instructor: Hanan Saleh
 * Lecture instructor: Philip Mees
 * Description: Header file for a small set of linked list functions.
 * The goal is to build, edit, and destroy a simple list of strings.
 * Filename: link.h
 *-------------------------------------------------------------*/

#ifndef LINK_H
#define LINK_H

// A basic structure for one "node" in the list.
// Think of it like a train car that holds a word (string) and connects to the next one.
struct node {
    char *data;           // the info we're storing (in this case, a string)
    struct node *next;    // pointer to the next node in the chain
};

/************************************************************************************************
 * Purpose:
 *   Go through the entire linked list and print out each string in it.
 *   Useful for checking what’s currently inside your list.
 * Parameters:
 *   - list: a pointer to the first node (head) of the list
 * Returns:
 *   Void(nothing)
 *********************************************************************/
void printList(struct node *list);

/***********************************************************
 * Purpose:
 *   Start a brand new linked list with one string.
 *   This is usually the first step before adding more.
 * Parameters:
 *   firstE: the string you want to put in the very first node
 * Returns:
 *   A pointer to the newly created node (the head of the list)
 */
struct node *createList(char *firstE);

/************************************************************************************
 * Purpose:
 *   Add a new node to the beginning of the list—like pushing something to the top of a stack.
 * Parameters:
 *  value: the string you want to add
 *  list: a pointer to the list pointer, since we may change the head
 * Returns:
 *  Void(nothing)
 */
void addFront(char *value, struct node **list);

/**********************************************************************************
 * Purpose:
 *   Attach a new node to the end of the list. Like adding to the end of a train.
 * Parameters:
 *  value: the string you want to add
 *  list: a pointer to the list pointer, since we need access to modify it
 * Returns:
 *  Void(nothing)
 ***********************************************************************************/
void addRear(char *value, struct node **list);

/****************************************************************************
 * Purpose:
 *   Find the first node with a matching string and remove it from the list.
 *   Only deletes one match, not all of them.
 * Parameters:
 *  value: the string you're looking to remove
 *  list: pointer to the list pointer, in case the head is removed
 * Returns:
 *  Void(nothing)
 ****************************************************************************/
void deleteNode(char *value, struct node **list);

/*********************************************************************************
 * Purpose:
 *   Clean up the entire list and free all the memory so we don't leak anything.
 *   After this, the list is empty and all nodes are gone.
 * Parameters:
 *  list: pointer to the list pointer, so we can empty and null it
 * Returns:
 *  void(nothing)
 *************************************************************************************/
void destroy(struct node **list);

#endif // LINK_H
