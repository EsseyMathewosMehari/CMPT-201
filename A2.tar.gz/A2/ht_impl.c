/*--------------------------------------------------------------
 * File: ht_impl.c
 * Author: Essey Mehari
 * For: CMPT 201, X02L
 * Lab Instructor: Hanan Saleh
 * Lecture Instructor: Philip Mees
 * Purpose: Implementation of hashtable ADT using separate chaining
 *-------------------------------------------------------------*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

#include "ht_impl.h"

#define START_SIZE 7  // initial number of buckets

/*******************************************************************************************
 * Purpose:
 *   Computes a hash value for a given string key using the djb2 algorithm.
 * Parameters:
 *   str: The string key to hash.
 * Returns:
 *   An unsigned long hash value.
 *******************************************************************************************/
static unsigned long hash_function(const char *str) {
    unsigned long hash = 5381;
    int c;

    while ((c = (unsigned char)*str++)) {
        hash = ((hash << 5) + hash) + c; /* hash * 33 + c */
    }
    return hash;
}

/*******************************************************************************************
 * Purpose:
 *   Creates a new empty hashtable with START_SIZE buckets.
 * Parameters:
 *   none
 * Returns:
 *   A pointer to the newly created hashtable, or NULL if allocation failed.
 *******************************************************************************************/
hashtable ht_impl_create(void) {
    struct hasht *ht = malloc(sizeof(struct hasht));
    if (ht == NULL) {
        return NULL;
    }

    ht->size = START_SIZE;
    ht->count = 0;

    ht->buckets = calloc(ht->size, sizeof(Node *));
    if (ht->buckets == NULL) {
        free(ht);
        return NULL;
    }
    return ht;
}

/*******************************************************************************************
 * Purpose:
 *   Frees all nodes in a linked list of Node structs.
 * Parameters:
 *   node: Pointer to the head of the linked list to free.
 * Returns:
 *   void
 *******************************************************************************************/
static void free_list(Node *node) {
    while (node != NULL) {
        Node *next = node->next;
        free(node->key);
        free(node->value);
        free(node);
        node = next;
    }
}

/*******************************************************************************************
 * Purpose:
 *   Frees all memory associated with the hashtable including all nodes and buckets.
 * Parameters:
 *   ht: The hashtable to free.
 * Returns:
 *   void
 *******************************************************************************************/
void ht_impl_free(hashtable ht) {
    if (ht == NULL) return;

    for (size_t i = 0; i < ht->size; i++) {
        free_list(ht->buckets[i]);
    }
    free(ht->buckets);
    free(ht);
}

/*******************************************************************************************
 * Purpose:
 *   Inserts a key-value pair into the hashtable.
 *   If the key already exists, updates the value.
 * Parameters:
 *   ht: The hashtable to modify.
 *   key: The key string (ownership transferred).
 *   value: The value string (ownership transferred).
 * Returns:
 *   void
 *******************************************************************************************/
void ht_impl_insert(hashtable ht, char *key, char *value) {
    if (ht == NULL || key == NULL || value == NULL) return;

    unsigned long hash = hash_function(key);
    size_t index = hash % ht->size;

    Node *cur = ht->buckets[index];
    while (cur != NULL) {
        if (strcmp(cur->key, key) == 0) {
            /* Key exists: update value */
            free(cur->value);
            cur->value = value;  // take ownership of new value
            free(key);           // free duplicate key
            return;
        }
        cur = cur->next;
    }

    /* Key not found: insert new node at head */
    Node *new_node = malloc(sizeof(Node));
    if (new_node == NULL) {
        /* On allocation failure, free inputs to avoid leaks */
        free(key);
        free(value);
        return;
    }

    new_node->key = key;
    new_node->value = value;
    new_node->next = ht->buckets[index];
    ht->buckets[index] = new_node;
    ht->count++;

    /* Note: No resizing implemented as per assignment */
}

/*******************************************************************************************
 * Purpose:
 *   Looks up the value associated with a given key in the hashtable.
 * Parameters:
 *   ht: The hashtable to search.
 *   key: The key to lookup.
 * Returns:
 *   Pointer to the value if found; NULL otherwise.
 *******************************************************************************************/
void *ht_impl_lookup(hashtable ht, const char *key) {
    if (ht == NULL || key == NULL) return NULL;

    unsigned long hash = hash_function(key);
    size_t index = hash % ht->size;

    Node *cur = ht->buckets[index];
    while (cur != NULL) {
        if (strcmp(cur->key, key) == 0) {
            return cur->value;
        }
        cur = cur->next;
    }
    return NULL;
}

/*******************************************************************************************
 * Purpose:
 *   Removes the key-value pair for the given key from the hashtable.
 * Parameters:
 *   ht: The hashtable to modify.
 *   key: The key to remove.
 * Returns:
 *   void
 *******************************************************************************************/
void ht_impl_remove(hashtable ht, const char *key) {
    if (ht == NULL || key == NULL) return;

    unsigned long hash = hash_function(key);
    size_t index = hash % ht->size;

    Node *cur = ht->buckets[index];
    Node *prev = NULL;

    while (cur != NULL) {
        if (strcmp(cur->key, key) == 0) {
            /* Found node to remove */
            if (prev == NULL) {
                ht->buckets[index] = cur->next;
            } else {
                prev->next = cur->next;
            }
            free(cur->key);
            free(cur->value);
            free(cur);
            ht->count--;
            return;
        }
        prev = cur;
        cur = cur->next;
    }
}
