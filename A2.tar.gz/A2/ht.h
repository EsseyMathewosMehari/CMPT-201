/* ht.h
 *
 * Public interface to the hashtable data structure.
 *
 * Please do not modify any code in this file!  We will be testing your code
 * under the assumption that the public interface matches this interface.
 *
 * Author: Essey Meharu=i
 * Lab instructor: <TODO:Hanan Saleh
 * Lecture instructor: <TOD>: Philip Mees
 */

#ifndef HT_H
#define HT_H

#define START_SIZE 7

/* With this incomplete declaration, other compilation units are aware of
 * the existence of a structure named 'hasht' but will not know anything about
 * its struct members, its size, etc. The actual definition will be written by
 * you and will reside in ht_impl.h header file, which will not be included by
 * external users of the hash table. In this way, we are able to ensure the
 * property of _information_hiding_behind_an_interface_boundary_.
 * All string variables stored in this struct must be stored in dynamic memory.
 */
struct hasht;


/* typedefs are not as commonly used as one might think, but two good reasons
 * to use them are:
 * a) simplifying a type by removing the 'struct' portion of the type;
 * b) abstracting away the pointer portion of the type, if users of the type
 * only pass the pointer around as a "handle" and never access its contents.
 *
 * We have done so here. In other words, the external users of the hashtable
 * data type may forget that under the hood, it is a pointer to a structure.
 */
typedef struct hasht *hashtable;


/******************************** Functions ***********************************/

/* We have prefaced all the function names with 'ht_'. In languages that support
 * modules, packages, or namespaces, this is unnecessary. However, giving a
 * common prefix to related functions helps in languages like C that do not
 * support namespacing. */

/* Allocates memory for a hashtable variable and any internal data structures
 * needed for an empty hash table. The initial size of the hashtable should be
 * equal to START_SIZE. If allocation is unsuccessful, this function returns
 * NULL. If allocation is successful, this function initializes an empty hash
 * table, and returns a hashtable variable.
 *
 * The caller is responsible for checking whether an allocation error occurred,
 * and for calling ht_free() on all dynamic memory that was allocated for this
 * hashtable when the data structure is no longer needed.
 */
hashtable ht_create(void);


/* Deallocates all memory used by the hashtable's internal data structures and
 * the hashtable itself. If the passed hashtable is the NULL pointer, this
 * function should inform the user and return. After freeing the memory and
 * returning, the hashtable cannot be used, since it now points to freed memory,
 * and should probably be assigned the value NULL for safety.
 */
void ht_free(hashtable ht);

/* Associates the supplied key with the supplied value in the hashtable.
 * Strings must be stored in dynamic memory.
 * Details will depend on how struct hasht is defined and how values are stored.
 * Combining multiple postal codes into a single value can either be done by the
 * calling program, or by ht_insert.
 *
 * Additionally, a resizing operation may occur during an insertion.
 * The table should be resized when it has reached a threshold fill level.
 */
void ht_insert(hashtable ht, char *key, char *value);


/* Finds the value associated with a given key. If the key is found, it returns
 * a pointer to the associated value, otherwise it returns NULL.
 *
 * Lookup needs to be O(1) in the number of elements in the hashtable.
 */
void *ht_lookup(hashtable ht, const char *key);


/* Removes the given key from the hashtable.
 *
 * If the key is not in the hashtable, nothing is done. Otherwise, the memory
 * held by the key and its value are freed, and any reference to the key is
 * removed from the hashtable's internal data structures. The collision
 * resolution method will determine what else this function needs to do.
 *
 * Removal needs to be O(1) in the number of elements in the hashtable.
 * A hashtable never needs to be reduced in size.
 */
void ht_remove(hashtable ht, const char *key);


/* This debugging function prints to standard output a list of keys in the
 * hashtable or NULL for empty table entries. For instance, if 'ht' is of size
 * 7 and contains 3 elements (Edmonton, Calgary, Montreal) then the printout
 * might look like this:
 *
 *  Calgary
 *  NULL
 *  NULL
 *  Edmonton
 *  Montreal
 *  NULL
 *  NULL
 *
 * To help debug the collision resolution method used for this assignment, you
 * may use additional ways of reporting the status of a hashtable entry.
 * Use this function to ensure that your hash function is doing a reasonable job
 * spreading keys evenly across the hash table and no clustering is occurring.
 * Additional output columns may be added for debugging purposes.
 */
void ht_print_dist(hashtable ht);


/* This function prints out the key, value pairs in the hashtable in the following
 * format. Empty entries are not printed.
 *
 * Key
 * Value
 *
 * Key
 * Value
 */
void ht_print(hashtable ht);

/* Returns the number of key-value pairs currently stored in the hashtable. */
int ht_size(hashtable ht);

/* Frees all memory associated with the hashtable, similar to ht_free, but
 * if your assignment expects a different name, use ht_destroy() */
void ht_destroy(hashtable ht);

#endif
