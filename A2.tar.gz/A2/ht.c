/*--------------------------------------------------------------
 * File: ht.c
 * Author: Essey Mehari
 * For: CMPT 201, X02L
 * Lab Instructor: Hanan Saleh
 * Lecture Instructor: Philip Mees
 * Purpose: Implementation file for hashtable ADT wrapper
 *-------------------------------------------------------------*/

#include "ht.h"
#include "ht_impl.h"  // Internal implementation header with struct hasht definition

/*
 * Creates and returns a new empty hashtable.
 * Returns NULL if memory allocation fails.
 */
hashtable ht_create(void) {
    return ht_impl_create();
}

/*
 * Frees all memory associated with the hashtable.
 * Does nothing if ht is NULL.
 */
void ht_free(hashtable ht) {
    ht_impl_free(ht);
}

/*
 * Inserts key-value pair into the hashtable.
 * Both key and value must be dynamically allocated strings.
 */
void ht_insert(hashtable ht, char *key, char *value) {
    ht_impl_insert(ht, key, value);
}

/*
 * Returns the value associated with key in the hashtable,
 * or NULL if key is not found.
 */
void *ht_lookup(hashtable ht, const char *key) {
    return ht_impl_lookup(ht, key);
}

/*
 * Removes the key and its associated value from the hashtable.
 * Does nothing if key is not found.
 */
void ht_remove(hashtable ht, const char *key) {
    ht_impl_remove(ht, key);
}
