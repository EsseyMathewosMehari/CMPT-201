/*--------------------------------------------------------------
 * File: ht_impl.h
 * Author: Essey Mehari
 * For: CMPT 201, X02L
 * Lab Instructor: Hanan Saleh
 * Lecture Instructor: Philip Mees
 * Purpose: Internal header file for hashtable implementation
 *-------------------------------------------------------------*/

#ifndef HT_IMPL_H
#define HT_IMPL_H

#include <stdbool.h>  // for bool
#include <stddef.h>   // for size_t

#include "ht.h"

/* Node struct for separate chaining linked list */
typedef struct node {
    char *key;
    char *value;
    struct node *next;
} Node;

/* Hashtable struct definition */
struct hasht {
    Node **buckets;     // array of bucket pointers (linked lists)
    size_t size;        // number of buckets
    size_t count;       // number of stored elements
};

/* Internal functions declarations */
hashtable ht_impl_create(void);
void ht_impl_free(hashtable ht);
void ht_impl_insert(hashtable ht, char *key, char *value);
void *ht_impl_lookup(hashtable ht, const char *key);
void ht_impl_remove(hashtable ht, const char *key);

#endif

