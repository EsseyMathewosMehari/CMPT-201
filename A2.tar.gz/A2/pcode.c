/*--------------------------------------------------------------
 * Written by: Essey Mehari
 * For: CMPT 201, X02L, A2
 * Lab instructor: Hanan Saleh
 * Lecture instructor: Philip Mees
 * Description: Main program reading postal codes and testing hash table.
 * Filename: pcode.c
 *-------------------------------------------------------------*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "ht.h"

#define MAX_LINE 256

int main(int argc, char *argv[])
{
    if (argc != 2) {
        fprintf(stderr, "Usage: %s <postalcodes_file>\n", argv[0]);
        return EXIT_FAILURE;
    }

    FILE *fp = fopen(argv[1], "r");
    if (!fp) {
        perror("Failed to open file");
        return EXIT_FAILURE;
    }

    hasht *ht = ht_create(100);
    if (!ht) {
        fprintf(stderr, "Failed to create hash table\n");
        fclose(fp);
        return EXIT_FAILURE;
    }

    char line[MAX_LINE];
    while (fgets(line, sizeof(line), fp)) {
        // Each line format: City,PostalCode\n
        char *newline = strchr(line, '\n');
        if (newline) *newline = '\0';

        char *comma = strchr(line, ',');
        if (!comma)
            continue; // skip bad lines

        *comma = '\0';
        const char *city = line;
        const char *postal = comma + 1;

        ht_insert(ht, city, postal);
    }

    fclose(fp);

    // Simple test lookups
    const char *tests[] = {"Windsor", "Montreal", "Quebec", "Toronto"};
    for (int i = 0; i < 4; i++) {
        const char *res = ht_lookup(ht, tests[i]);
        if (res)
            printf("%s: %s\n", tests[i], res);
        else
            printf("%s: NOT FOUND\n", tests[i]);
    }

    ht_destroy(ht);
    return EXIT_SUCCESS;
}
