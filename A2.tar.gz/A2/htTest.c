/*--------------------------------------------------------------
 * Written by: Essey Mehari
 * For: CMPT 201, X02L, Assignment 2
 * Lab instructor: Hanan Saleh
 * Lecture instructor: Philip Mees
 * Program/Module purpose: Tests hash table functions
 *--------------------------------------------------------------*/

#include <stdio.h>
#include "ht.h"

int main(void) {
    // Create a new empty hashtable
    hashtable ht = ht_create();

    // Insert some key-value pairs (city and postal code) into the hashtable
    ht_insert(ht, "Calgary", "T2A");
    ht_insert(ht, "Edmonton", "T5J");
    ht_insert(ht, "Vancouver", "V6B");

    // Lookup the postal code for "Edmonton"
    char *result = ht_lookup(ht, "Edmonton");
    if (result != NULL)
        printf("Edmonton postal code: %s\n", result);  // Print found postal code
    else
        printf("Edmonton not found\n");  // Key not found in hashtable

    // Lookup the postal code for "Toronto" (not inserted)
    result = ht_lookup(ht, "Toronto");
    if (result != NULL)
        printf("Toronto postal code: %s\n", result);  // Should not print in this test
    else
        printf("Toronto not found\n");  // Expected: key not found

    // Free all memory associated with the hashtable
    ht_free(ht);

    return 0;  // Exit program successfully
}
