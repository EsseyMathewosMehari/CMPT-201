/*:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
 * Written by: Essey Mehari
 * For: CMPT 201, X02L, Lab Exercise 7
 * Lab instructor: Hanan Saleh
 * Lecture instructor: Philip Mees
 * Description: Lab 7 exercise 1
 *              Sorting array of game structs using qsort,
 *              bitfields for popularity,
 *              writing/reading binary files,
 *              printing with manual padding for alignment.
 * Filename: lab7E1.c
 *:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct {
    char title[25];
    double price;
    unsigned int popularity : 3;  // only 3 bits needed for values 1-4
} game;

/*******************************************************************************************
 * Purpose:
 *   Compare two game structs by title for qsort.
 * Parameters:
 *   const void *a : pointer to first game struct
 *   const void *b : pointer to second game struct
 * Returns:
 *   int : negative if a < b, 0 if equal, positive if a > b (alphabetically)
 *******************************************************************************************/
int compGamesByTitle(const void *a, const void *b) {
    const game *g1 = (const game *)a;
    const game *g2 = (const game *)b;
    return strcmp(g1->title, g2->title);
}

/*******************************************************************************************
 * Purpose:
 *   Compare two game structs by price for qsort.
 * Parameters:
 *   const void *a : pointer to first game struct
 *   const void *b : pointer to second game struct
 * Returns:
 *   int : negative if a < b, 0 if equal, positive if a > b (by price ascending)
 *******************************************************************************************/
int compGamesByPrice(const void *a, const void *b) {
    const game *g1 = (const game *)a;
    const game *g2 = (const game *)b;
    if (g1->price < g2->price) return -1;
    else if (g1->price > g2->price) return 1;
    else return 0;
}

/*******************************************************************************************
 * Purpose:
 *   Print a single game struct in a nicely aligned format using manual padding.
 * Parameters:
 *   const game *g : pointer to the game struct to print
 * Returns:
 *   void
 *******************************************************************************************/
void printGame(const game *g) {
    int pad = 25 - (int)strlen(g->title);  // spaces to add after title
    printf("%s", g->title);
    for (int i = 0; i < pad; i++) {
        putchar(' ');
    }
    printf("$%-7.2f %u\n", g->price, g->popularity);
}

/*******************************************************************************************
 * Purpose:
 *   Print header row for game table.
 * Parameters:
 *   void
 * Returns:
 *   void
 *******************************************************************************************/
void printHeader(void) {
    printf("Title                    Price    Popularity\n");
    printf(":::::::::::::::::::::::::::::::::::::::::::\n");
}

/*******************************************************************************************
 * Purpose:
 *   Write an array of game structs to a binary file.
 *   First writes the length (unsigned int), then the array data.
 * Parameters:
 *   const char *filename : name of the file to write to
 *   const game *games : pointer to the array of games to write
 *   unsigned int length : number of games in the array
 * Returns:
 *   void
 *******************************************************************************************/
void writeBinary(const char *filename, const game *games, unsigned int length) {
    FILE *fp = fopen(filename, "wb");
    if (fp == NULL) {
        perror("Failed to open file for writing");
        return;
    }
    fwrite(&length, sizeof(unsigned int), 1, fp);
    fwrite(games, sizeof(game), length, fp);
    fclose(fp);
}

/*******************************************************************************************
 * Purpose:
 *   Read an array of game structs from a binary file.
 *   Reads length first, then allocates and reads array.
 * Parameters:
 *   const char *filename : name of the file to read from
 *   game **games : pointer to store allocated array pointer
 *   unsigned int *length : pointer to store length of array read
 * Returns:
 *   int : 0 on success, non-zero on failure
 *******************************************************************************************/
int readBinary(const char *filename, game **games, unsigned int *length) {
    FILE *fp = fopen(filename, "rb");
    if (fp == NULL) {
        perror("Failed to open file for reading");
        return 1;
    }
    if (fread(length, sizeof(unsigned int), 1, fp) != 1) {
        fclose(fp);
        fprintf(stderr, "Failed to read length from file\n");
        return 2;
    }
    *games = malloc(sizeof(game) * (*length));
    if (*games == NULL) {
        fclose(fp);
        fprintf(stderr, "Memory allocation failed\n");
        return 3;
    }
    if (fread(*games, sizeof(game), *length, fp) != *length) {
        free(*games);
        fclose(fp);
        fprintf(stderr, "Failed to read game data from file\n");
        return 4;
    }
    fclose(fp);
    return 0;
}

int main(void) {
    // a) Create static array with given data
    game games[] = {
        {"PUBG: Battlegrounds", 1.29, 3},
        {"Super Mario Bros.", 18.49, 4},
        {"Grand Theft Auto V", 37.85, 2},
        {"Red Dead Redemption 2", 56.99, 4},
        {"Tetris", 1.59, 3},
        {"Minecraft", 31.50, 1}
    };
    unsigned int length = sizeof(games) / sizeof(games[0]);

    // b) Print original array
    printf("Original array:\n");
    printHeader();
    for (unsigned int i = 0; i < length; i++) {
        printGame(&games[i]);
    }
    printf("\n");

    // c) Sort by title
    qsort(games, length, sizeof(game), compGamesByTitle);

    // d) Print sorted by title
    printf("Sorted by title:\n");
    printHeader();
    for (unsigned int i = 0; i < length; i++) {
        printGame(&games[i]);
    }
    printf("\n");

    // e) Sort by price
    qsort(games, length, sizeof(game), compGamesByPrice);

    // f) Print sorted by price
    printf("Sorted by price:\n");
    printHeader();
    for (unsigned int i = 0; i < length; i++) {
        printGame(&games[i]);
    }
    printf("\n");

    // h) Write sorted array to binary file
    writeBinary("games.bin", games, length);

    // i) Read from binary file into new array
    game *gamesFromFile = NULL;
    unsigned int newLength = 0;
    if (readBinary("games.bin", &gamesFromFile, &newLength) != 0) {
        fprintf(stderr, "Error reading binary file.\n");
        return 1;
    }

    // j) Print new array read from file
    printf("Read from binary file:\n");
    printHeader();
    for (unsigned int i = 0; i < newLength; i++) {
        printGame(&gamesFromFile[i]);
    }
    printf("\n");

    free(gamesFromFile);
    return 0;
}
