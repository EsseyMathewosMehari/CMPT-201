/*--------------------------------------------------------------
 * Written by: Your Name
 * For: CMPT 201, X02L, Lab Exercise A1
 * Lab instructor: Hanan Saleh
 * Lecture instructor: Philip Mees
 * Program/Module purpose: Compress repeated characters in input lines.
 */

#include <stdio.h>

#define MAX_LINE 1000

int main() {
    char line[MAX_LINE];

    while (fgets(line, MAX_LINE, stdin) != NULL) {
        int i = 0, count = 1;
        char current = line[0];

        while (line[i] != '\0' && line[i] != '\n') {
            if (line[i] == line[i+1] && count < 9) {
                count++;
            } else {
                // print the character and count if more than 1
                if (count > 1)
                    printf("%c%d", line[i], count);
                else
                    printf("%c", line[i]);
                count = 1;
            }
            i++;
        }
        printf("\n");
    }

    return 0;
}
