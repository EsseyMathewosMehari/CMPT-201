/*--------------------------------------------------------------
 * Written by: Essey Mehari
 * For: CMPT 201, X02L, Lab Exercise A1
 * Lab instructor: Hanan Saleh
 * Lecture instructor: Philip Mees
 * Program/Module purpose: Reads lines from stdin and prints
 * their characters sorted by ASCII (cardinal sort).
 */

#include <stdio.h>
#define MAX_LINE 1000

int main() {
    char line[MAX_LINE];
    int count[128];  // ASCII table size

    while (fgets(line, MAX_LINE, stdin) != NULL) {
        // Initialize counts
        for (int i = 0; i < 128; i++) {
            count[i] = 0;
        }

        // Count printable ASCII chars only
        for (int i = 0; line[i] != '\0'; i++) {
            unsigned char c = line[i];
            if (c >= 32 && c <= 126) {
                count[c]++;
            }
        }

        // Print characters in ASCII order as many times as counted
        for (int i = 32; i <= 126; i++) {
            for (int j = 0; j < count[i]; j++) {
                putchar(i);
            }
        }
        putchar('\n');
    }
    return 0;
}
