/*--------------------------------------------------------------
 * Written by: Essey Mehari
 * For: CMPT 201, X02L, Lab Exercise A1
 * Lab instructor: Hanan Saleh
 * Lecture instructor: Philip Mees
 * Program/Module purpose: Counts COVID-19 cases per date from CSV input.
 */

#include <stdio.h>
#include <string.h>

#define MAX_LINE 256

int main() {
    char line[MAX_LINE];
    char date[11] = "";       // YYYY/MM/DD plus null terminator
    char current_date[11] = "";
    int count = 0;

    // Skip header line
    if (fgets(line, MAX_LINE, stdin) == NULL) {
        return 1; // no input
    }

    while (fgets(line, MAX_LINE, stdin) != NULL) {
        // Extract date field from line (second field in CSV)

        // Find first comma
        char *first_comma = strchr(line, ',');
        if (!first_comma) continue;

        // Find second comma after first
        char *second_comma = strchr(first_comma + 1, ',');
        if (!second_comma) continue;

        // Copy date between first_comma+1 and second_comma
        int len = second_comma - first_comma - 1;
        if (len > 10) len = 10; // limit to date length
        strncpy(date, first_comma + 1, len);
        date[len] = '\0';

        // Remove spaces around date if any
        // Trim leading spaces
        char *start = date;
        while (*start == ' ') start++;
        if (start != date) memmove(date, start, strlen(start) + 1);

        // Convert '/' to '-' for output format YYYY-MM-DD
        for (int i = 0; date[i]; i++) {
            if (date[i] == '/') {
                date[i] = '-';
            }
        }

        if (strcmp(date, current_date) == 0) {
            // Same date as previous line
            count++;
        } else {
            // New date, print previous date count if any
            if (current_date[0] != '\0') {
                printf("%s %d\n", current_date, count);
            }
            strcpy(current_date, date);
            count = 1;
        }
    }

    // Print last date count
    if (current_date[0] != '\0') {
        printf("%s %d\n", current_date, count);
    }

    return 0;
}
