/*--------------------------------------------------------------
 * Written by: Essey Mehari
 * For: CMPT 201, X02L, Lab Exercise A1
 * Lab instructor: Hanan Saleh
 * Lecture instructor:  Philip Mees
 * Finds and prints all prime pairs (p, p+d)less than n.
 * LabA1
*/
#include <stdio.h>

/*Function to check if a number is prime*/
int isPrime(int n) 
{
    int i;
    if (n < 2) return 0;
    for (i = 2; i * i <= n; i++) {
        if (n % i == 0)
            return 0;
    }
    return 1;
}

/* Function to print all prime pairs with difference */
void printPrimePairs(int n, int d)
{
    int i;
    i = 2;
    while (i < n - d) {
        if (isPrime(i) && isPrime(i + d)) {
            printf("(%d %d)\n", i, i + d);
        }
        i++;
    }
}

/* Main function */
int main()
{
    int n, d;

    /* Read n and d until Ctrl-D (EOF) */
    while (scanf("%d %d", &n, &d) == 2) {
        printPrimePairs(n, d);
    }

    return 0;
}
