Testing Strategy for Assignment Programs

countingCovid.c:
- Test 1: Simple input with multiple dates and multiple cases on some dates.
  Checks that counting per date works correctly.
- Test 2: Input with dates in sequence and multiple cases on same dates.
  Tests if the program correctly resets count on date change.
- Additional edge cases could include no cases or only one date.

cardinalSort.c:
- Tested with input arrays sorted in ascending, descending and random order.
- Tested with duplicate values.
- Tested with empty input.

squeeze.c:
- Tested with input strings containing repeated characters.
- Tested with strings having no repeats.
- Tested with very long sequences (>9 repeats) to check count splitting.

primeDiff.c:
- Tested with prime numbers close together.
- Tested with large gaps.
- Tested with minimum and maximum input values.

xTable.c:
- Compared the entire output against a verified correct output file.
- Checked alignment and formatting.
