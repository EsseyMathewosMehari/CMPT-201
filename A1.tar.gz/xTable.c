/*--------------------------------------------------------------
 * Written by: Essey Mehari
 * For: CMPT 201, X02L, Lab Exercise A1
 * Lab instructor: Hanan Saleh
 * Lecture instructor: Philip Mees
 * Program/Module purpose: Prints a table of the function
 * f(x,y) = x^3 / (y^2 + 1) for x = 3,6,...,30 and y = 0..20 in a formatted table.
 */

#include <stdio.h>
#include <math.h>

/* Main function */
int main() {
    int x, y;

    /* Print top row header */
    printf("+ ");
    for (x = 3; x <= 30; x += 3) {
        printf("%3d ", x);
    }
    printf("\n");

    /* Print table rows */
    for (y = 0; y <= 20; y++) {
        printf("%-2d ", y);  /* Print y label left aligned with width 2 */

        for (x = 3; x <= 30; x += 3) {
            double val = pow(x, 3) / (y * y + 1);
            printf("%5.1f ", val);
        }
        printf("\n");
    }

    return 0;
}
