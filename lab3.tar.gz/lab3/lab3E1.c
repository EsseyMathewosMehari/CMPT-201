/*--------------------------------------------------------------
 * Written by: Essey Mehari
 * For: CMPT 201, X02L, Lab Exercise 3
 * Lab instructor: Hanan Saleh
 * Lecture instructor:  Philip Mees
 * Program/Module purpose: Prints the item count, total price, and purchase date in a neatly aligned format 
 * Lab3
*/
#include <stdio.h>

int main(void) {
    int itemCount, day, month, year;
    float unitPrice, totalPrice;

    // Prompt user input
    printf("Enter number of items: ");
    scanf("%d", &itemCount);

    printf("Enter unit price: ");
    scanf("%f", &unitPrice);

    printf("Enter date (dd/mm/yyyy): ");
    scanf("%d/%d/%d", &day, &month, &year);

    // Calculate total
    totalPrice = itemCount * unitPrice;

    // Output
    printf("\nItem      Total      Purchase\n");
    printf("Count     Price      Date\n");
    printf("%-9d$ %-10.2f%4d: %d/%d\n", itemCount, totalPrice, year, day, month);

    return 0;
}
