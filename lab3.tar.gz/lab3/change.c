// change.c
// Implements changeCalculator to print breakdown of change

#include <stdio.h>
#include "change.h"

void changeCalculator(int billedAmount, int amountGiven) {
    int change = amountGiven - billedAmount;

    int fifty = change / 5000;
    change %= 5000;

    int ten = change / 1000;
    change %= 1000;

    int two = change / 200;
    change %= 200;

    int dime = change / 10;
    change %= 10;

    int change_dollars = (amountGiven - billedAmount) / 100;
    int change_cents = (amountGiven - billedAmount) % 100;

    printf("Change of $%d.%02d:\n", change_dollars, change_cents);

    if (fifty > 0) printf("%d fifty dollar bill\n", fifty);
    if (ten > 0)   printf("%d ten dollar bill\n", ten);
    if (two > 0)   printf("%d two dollar coin\n", two);
    if (dime > 0)  printf("%d dime\n", dime);
}
