/*--------------------------------------------------------------
 * Written by: Essey Mehari
 * For: CMPT 201, X02L, Lab Exercise 3
 * Lab instructor: Hanan Saleh
 * Lecture instructor:  Philip Mees
 * Program/Module purpose: Prints the item count, total price, and purchase date in a neatly aligned format
lab3E3.c*/

#include <stdio.h>
#include "change.h"

int main(void) {
    int billed_d, billed_c;
    int paid_d, paid_c;
    char tch;

    while ((tch = getchar()) != EOF) {
        ungetc(tch, stdin);  // Put it back for scanf

        // Try to scan 4 integers: billed dollars/cents and paid dollars/cents
        if (scanf("%d.%d %d.%d", &billed_d, &billed_c, &paid_d, &paid_c) == 4) {
            int billedAmount = billed_d * 100 + billed_c;
            int paidAmount = paid_d * 100 + paid_c;

            changeCalculator(billedAmount, paidAmount);
            printf("\n");
        }

        // Skip rest of the line (if any garbage or extra input)
        while (getchar() != '\n' && !feof(stdin)) {}
    }

    return 0;
}


/* echoNum.c
 * Simple program which reads numbers in double precision from stdin
 * and prints them on the stdout.
 * It reads several lines of input until it encounters end of file */

//#include <stdio.h>

//int main(void) {
//    double number;/
//    char tch;

//    while ((tch = getchar()) != EOF) {  //If character is not end of file
//        ungetc(tch, stdin);    //Put it back to stdin for further processing

//        scanf("%lf", &number);    //Read a number
//        printf("%lf\n", number);  //Print it

//        while (getchar() != '\n') {}    // skip the rest of the line
//   }
//   return 0;
//}
