// change.h
// Function prototype for changeCalculator

#ifndef CHANGE_H
#define CHANGE_H

void changeCalculator(int billedAmount, int amountGiven);

#endif
