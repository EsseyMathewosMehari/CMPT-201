/*--------------------------------------------------------------
 * Written by: Essey Mehari
 * For: CMPT 201, X02L, Lab Exercise 3
 * Lab instructor: Hanan Saleh
 * Lecture instructor:  Philip Mees
 * Program/Module purpose: Prints the item count, total price, and purchase date in a neatly aligned format
 * Lab3E2.c
*/
#include <stdio.h>

int main(void) {
    int owed_dollars, owed_cents;
    int paid_dollars, paid_cents;
    int owed_total, paid_total, change;

    // Get input from user
    printf("Enter amount owed: ");
    scanf("%d.%d", &owed_dollars, &owed_cents);

    printf("Enter amount paid: ");
    scanf("%d.%d", &paid_dollars, &paid_cents);

    // Convert all to cents
    owed_total = owed_dollars * 100 + owed_cents;
    paid_total = paid_dollars * 100 + paid_cents;

    // Calculate change
    change = paid_total - owed_total;

    int fifty = change / 5000;
    change %= 5000;

    int ten = change / 1000;
    change %= 1000;

    int two = change / 200;
    change %= 200;

    int dime = change / 10;
    change %= 10;

    // Output results
    int change_dollars = (paid_total - owed_total) / 100;
    int change_cents = (paid_total - owed_total) % 100;

    printf("Change of $%d.%02d:\n", change_dollars, change_cents);

    if (fifty > 0) printf("%d fifty dollar bill\n", fifty);
    if (ten > 0)   printf("%d ten dollar bill\n", ten);
    if (two > 0)   printf("%d two dollar coin\n", two);
    if (dime > 0)  printf("%d dime\n", dime);

    return 0;
}
