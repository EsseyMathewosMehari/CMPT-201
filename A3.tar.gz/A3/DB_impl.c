/* DB_impl.c
 *
 * Description: This file currently searches for an existing string value in a look 
                up table, if value is not found, the function dynamically resizes table
                , allocates memory, inserts new string and assigns new ID. 
 *
 * Author: Abhay Handa
 * findOrInsert()
 * Lab instructor: Hanan Saleh
 * Lecture instructor: Philip Mees
 * CMPT-201-X02l
 */

#include "DB.h"       /* Import the public database header. */
#include "DB_impl.h"  /* Import the private database header */

int findOrInsert(LookupTable **table, int *count, int *cap, const char *value) {

  //printf("Found existing: %s → ID %d\n", value, (*table)[i].id);

  // searches for the value in existing table
  for (int i = 0; i < *count; i++) { 
    if (strcmp((*table)[i].type, value) == 0) {
      return (*table)[i].id; //returns the existing id
    }
  }

  // resizes table when it reaches capacity
  if (*count >= *cap) { 
    
    *cap *= 2;
    *table = realloc(*table,(*cap) * sizeof(LookupTable));

      // checks if fail, returns null and exits program
      if (!*table) { 
        fprintf(stderr, "Memory Allocation Failed during table resize.\n");
        exit(1);
      }
  }

  // inserts new value at the end of table
  int newID = *count;
  (*table)[newID].id = newID;
  (*table)[newID].type = malloc(strlen(value) + 1);
  
  
  // checks if malloc returns null, then will exit program. 
  if (!(*table)[newID].type) { 
      fprintf(stderr, "Memory Allocation failed for new string.\n");
      exit(1);
  }
  
  strcpy((*table)[newID].type, value);  // copies value into allocated space

  //printf("Inserted new: %s → ID %d\n", value, newID);
  (*count)++;    // updates record count

  return newID;    //returns new id 
}
