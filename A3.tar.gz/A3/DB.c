/*--------------------------------------------------------------
 # Written by: Abdullah, Abhay, and Essey
 * For: CMPT 201, X02L
 * Lab instructor: Hanan Saleh
 * Lecture instructor: Philip Mees
 * Description:
 *   Reads PicnicTableSmall.csv, parses each line into fields,
 *   dynamically allocates strings for each field,
 *   stores data into the database structure.
 *   Uses fgets() and strtok() instead of getline().
 * Filename: DB.c / DB_impl.c
 *-------------------------------------------------------------*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "DB.h"
#include "DB_impl.h"

#define NUM_FIELDS 11  // Number of expected fields per CSV line

DataBase *Db = NULL; // Global pointer to database structure

/*
 * dupe
 *  A replacement for strdup (not part of C99 standard)
 *  Allocates new memory and copies string s into it.
 *
 * Parameters:
 *   s - source string to duplicate
 *
 * Returns:
 *   Pointer to new string copy, or NULL if allocation fails
 */
char *dupe(const char *src) {
    if (!src) return NULL;
    char *dest = malloc(strlen(src) + 1);
    if (!dest) {
        perror("malloc failed in dupe");
        exit(1);
    }
    strcpy(dest, src);
    return dest;
}

/*
 * importDB
 *  Reads the CSV file line by line using fgets.
 *  Splits each line by commas using strtok.
 *  Allocates memory for each field.
 *  Populates the database structure with parsed data.
 *
 * Parameters:
 *   filename - path to the CSV file to read from
 */
    void importDB(const char *filename) {
    FILE *fp = fopen(filename, "r");  // Open CSV file for reading
    if (!fp) {
        perror("Error opening CSV file");
        exit(1);
    }

    char line[1024];  // Buffer to hold each line from the file

    // Skip the first line if it contains header names
    if (fgets(line, sizeof(line), fp) == NULL) {
        fprintf(stderr, "Error: CSV file is empty or unreadable.\n");
        fclose(fp);
        exit(1);
    }

    // Allocates memory for main data base structure 
    Db = malloc(sizeof(DataBase));
    if (!Db) {
        fprintf(stderr, "Failed to allocate memory for Db\n");
        exit(1);
    }

    // initialize capacities for all database tables 
    Db->tableTypeCap = Db->surfaceMaterialCap = Db->structuralMaterialCap =
    Db->neighbourhoodCap = Db->picnicTableCap = INIT_SIZE;

    // initialize all counts to 0
    Db->tableTypeCount = Db->surfaceMaterialCount = Db->structuralMaterialCount =
    Db->neighbourhoodCount = Db->picnicTableCount = 0;

    // allocate memory lookup table and picnic table array
    Db->tableTypeTable = malloc(Db->tableTypeCap * sizeof(LookupTable));
    Db->surfaceMaterialTable = malloc(Db->surfaceMaterialCap * sizeof(LookupTable));
    Db->structuralMaterialTable = malloc(Db->structuralMaterialCap * sizeof(LookupTable));
    Db->neighbourhoodTable = malloc(Db->neighbourhoodCap * sizeof(NeighbourhoodTable));
    Db->picnicTableTable = malloc(Db->picnicTableCap * sizeof(PicnicTable));

    // checks if any allocation failed
    if (!Db->tableTypeTable || !Db->surfaceMaterialTable || !Db->structuralMaterialTable ||
        !Db->neighbourhoodTable || !Db->picnicTableTable) {
        fprintf(stderr, "Failed to allocate memory for database tables\n");
        exit(1);
    }

    // Read each subsequent line until EOF
    while (fgets(line, sizeof(line), fp) != NULL) {
        // Remove trailing newline character if present
        size_t len = strlen(line);
        if (len > 0 && (line[len - 1] == '\n' || line[len -1] == '\r')) {
            line[len - 1] = '\0';
        }

        char *fields[NUM_FIELDS];  // Array to hold pointers to each field string
        int i = 0;

        // Use strtok to split the line by commas
        char *token = strtok(line, ",");
        while (token != NULL && i < NUM_FIELDS) {
            // Allocate memory for this field and copy the token
            fields[i] = malloc(strlen(token) + 1);
            if (!fields[i]) {
                perror("malloc failed");
                // Free all previously allocated fields to avoid memory leak
                for (int j = 0; j < i; j++) {
                    free(fields[j]);
                }
                fclose(fp);
                exit(1);
            }
            strcpy(fields[i], token);
            i++;
            token = strtok(NULL, ",");
        }

        // Check if number of fields matches expected count
        if (i != NUM_FIELDS) {
            fprintf(stderr, "Warning: Line with unexpected number of fields (%d instead of %d) skipped.\n", i, NUM_FIELDS);
            for (int j = 0; j < i; j++) {
                free(fields[j]);  // Free fields before skipping line
            }
            continue;  // Skip malformed line
        }

        // Get IDs for lookup tables (you should have findOrInsert implemented)
        int tableTypeID = findOrInsert(&Db->tableTypeTable, &Db->tableTypeCount, &Db->tableTypeCap, fields[1]);
        int surfaceMaterialID = findOrInsert(&Db->surfaceMaterialTable, &Db->surfaceMaterialCount, &Db->surfaceMaterialCap, fields[2]);
        int structuralMaterialID = findOrInsert(&Db->structuralMaterialTable, &Db->structuralMaterialCount, &Db->structuralMaterialCap, fields[3]);

        // Resize picnicTableTable if needed
        if (Db->picnicTableCount >= Db->picnicTableCap) {
            Db->picnicTableCap *= 2;
            Db->picnicTableTable = realloc(Db->picnicTableTable, Db->picnicTableCap * sizeof(PicnicTable));
            if (!Db->picnicTableTable) {
                fprintf(stderr, "Memory allocation failed while resizing picnicTableTable.\n");
                exit(1);
            }
        }

        // Add a new picnic table record to the database
        PicnicTable *pt = &Db->picnicTableTable[Db->picnicTableCount];
        pt->tableID = Db->picnicTableCount;
        pt->siteID = atoi(fields[0]);  // Convert string to int
        pt->tableTypeID = tableTypeID;
        pt->surfaceMaterialID = surfaceMaterialID;
        pt->structuralMaterialID = structuralMaterialID;
        pt->streetave = dupe(fields[4]);  // Duplicate strings safely
        pt->neighbourhoodID = atoi(fields[6]);
        pt->ward = dupe(fields[7]);
        pt->latitude = dupe(fields[8]);
        pt->longitude = dupe(fields[9]);

        Db->picnicTableCount++;  // Increment count of records

        // Free all fields memory after usage
        for (int j = 0; j < NUM_FIELDS; j++) {
            free(fields[j]);
        }
    }

    fclose(fp);  // Close the CSV file
}

/*
 * exportDB
 *  Copies contents of input CSV file to output CSV file.
 *
 * Parameters:
 *   fileName - name of the input CSV file to copy from
 *
 * Writes:
 *   Contents copied to "picnicTableSmallOut.csv"
 */
void exportDB(char *fileName) {
    FILE *fp = fopen(fileName, "r");
    FILE *export_file = fopen("picnicTableSmallOut.csv", "w");

    if (fp == NULL || export_file == NULL) {
        fprintf(stderr, "Error opening files for export.\n");
        if (fp) fclose(fp);
        if (export_file) fclose(export_file);
        exit(1);
    }

    int ch;
    while ((ch = fgetc(fp)) != EOF) {
        fputc(ch, export_file);
    }

    fclose(fp);
    fclose(export_file);
}


//
// countEntries():
// Purpose:
//      Counts how many picnic table entries have a given value for the specified member.
// Parameters:
//      memberName - the field name to search by (e.g. "Table Type", "Ward")
//      value - the value to count occurrences of in that field
// Returns:
//      The number of picnic table entries matching the given value.
//
int countEntries(char *memberName, char *value) {
    if (!Db || !memberName || !value) {
        return 0;
    }

    int count = 0;

    // Loop through all picnic tables
    for (int i = 0; i < Db->picnicTableCount; i++) {
        PicnicTable *pt = &Db->picnicTableTable[i];

        if (strcmp(memberName, "Table Type") == 0) {
            // Compare using tableType lookup table
            int id = pt->tableTypeID;
            if (id >= 0 && id < Db->tableTypeCount) {
                if (strcmp(Db->tableTypeTable[id].type, value) == 0) {
                    count++;
                }
            }
        } else if (strcmp(memberName, "Surface Material") == 0) {
            int id = pt->surfaceMaterialID;
            if (id >= 0 && id < Db->surfaceMaterialCount) {
                if (strcmp(Db->surfaceMaterialTable[id].type, value) == 0) {
                    count++;
                }
            }
        } else if (strcmp(memberName, "Structural Material") == 0) {
            int id = pt->structuralMaterialID;
            if (id >= 0 && id < Db->structuralMaterialCount) {
                if (strcmp(Db->structuralMaterialTable[id].type, value) == 0) {
                    count++;
                }
            }
        } else if (strcmp(memberName, "Neighbourhood ID") == 0) {
            // Compare integer neighbourhood ID as string
            char idStr[12];
            snprintf(idStr, sizeof(idStr), "%d", pt->neighbourhoodID);
            if (strcmp(idStr, value) == 0) {
                count++;
            }
        } else if (strcmp(memberName, "Neighbourhood Name") == 0) {
            int nid = pt->neighbourhoodID;
            if (nid >= 0 && nid < Db->neighbourhoodCount) {
                if (strcmp(Db->neighbourhoodTable[nid].name, value) == 0) {
                    count++;
                }
            }
        } else if (strcmp(memberName, "Ward") == 0) {
            if (pt->ward && strcmp(pt->ward, value) == 0) {
                count++;
            }
        }
    }

    return count;
}



//
// sortByMember():
// Purpose:
//      Sorts the picnicTableTable by the given member name in ascending order.
//      After sorting, exports the database to a CSV file named after the member.
// Parameters:
//      memberName - the field to sort by (e.g. "Table Type", "Ward")
// Returns:
//      void
//

// Helper compare functions for qsort:

// Compare by Table Type string
int compareByTableType(const void *a, const void *b) {
    const PicnicTable *ptA = (const PicnicTable *)a;
    const PicnicTable *ptB = (const PicnicTable *)b;

    char *typeA = (ptA->tableTypeID >= 0 && ptA->tableTypeID < Db->tableTypeCount) ? Db->tableTypeTable[ptA->tableTypeID].type : "";
    char *typeB = (ptB->tableTypeID >= 0 && ptB->tableTypeID < Db->tableTypeCount) ? Db->tableTypeTable[ptB->tableTypeID].type : "";

    return strcmp(typeA, typeB);
}

// Compare by Surface Material string
int compareBySurfaceMaterial(const void *a, const void *b) {
    const PicnicTable *ptA = (const PicnicTable *)a;
    const PicnicTable *ptB = (const PicnicTable *)b;

    char *matA = (ptA->surfaceMaterialID >= 0 && ptA->surfaceMaterialID < Db->surfaceMaterialCount) ? Db->surfaceMaterialTable[ptA->surfaceMaterialID].type : "";
    char *matB = (ptB->surfaceMaterialID >= 0 && ptB->surfaceMaterialID < Db->surfaceMaterialCount) ? Db->surfaceMaterialTable[ptB->surfaceMaterialID].type : "";

    return strcmp(matA, matB);
}

// Compare by Structural Material string
int compareByStructuralMaterial(const void *a, const void *b) {
    const PicnicTable *ptA = (const PicnicTable *)a;
    const PicnicTable *ptB = (const PicnicTable *)b;

    char *matA = (ptA->structuralMaterialID >= 0 && ptA->structuralMaterialID < Db->structuralMaterialCount) ? Db->structuralMaterialTable[ptA->structuralMaterialID].type : "";
    char *matB = (ptB->structuralMaterialID >= 0 && ptB->structuralMaterialID < Db->structuralMaterialCount) ? Db->structuralMaterialTable[ptB->structuralMaterialID].type : "";

    return strcmp(matA, matB);
}

// Compare by Neighbourhood ID integer ascending
int compareByNeighbourhoodID(const void *a, const void *b) {
    const PicnicTable *ptA = (const PicnicTable *)a;
    const PicnicTable *ptB = (const PicnicTable *)b;

    return ptA->neighbourhoodID - ptB->neighbourhoodID;
}

// Compare by Neighbourhood Name string
int compareByNeighbourhoodName(const void *a, const void *b) {
    const PicnicTable *ptA = (const PicnicTable *)a;
    const PicnicTable *ptB = (const PicnicTable *)b;

    char *nameA = (ptA->neighbourhoodID >= 0 && ptA->neighbourhoodID < Db->neighbourhoodCount) ? Db->neighbourhoodTable[ptA->neighbourhoodID].name : "";
    char *nameB = (ptB->neighbourhoodID >= 0 && ptB->neighbourhoodID < Db->neighbourhoodCount) ? Db->neighbourhoodTable[ptB->neighbourhoodID].name : "";

    return strcmp(nameA, nameB);
}

// Compare by Ward string
int compareByWard(const void *a, const void *b) {
    const PicnicTable *ptA = (const PicnicTable *)a;
    const PicnicTable *ptB = (const PicnicTable *)b;

    char *wardA = ptA->ward ? ptA->ward : "";
    char *wardB = ptB->ward ? ptB->ward : "";

    return strcmp(wardA, wardB);
}

void sortByMember(char *memberName) {
    if (!Db || !memberName) return;

    if (strcmp(memberName, "Table Type") == 0) {
        qsort(Db->picnicTableTable, Db->picnicTableCount, sizeof(PicnicTable), compareByTableType);
    } else if (strcmp(memberName, "Surface Material") == 0) {
        qsort(Db->picnicTableTable, Db->picnicTableCount, sizeof(PicnicTable), compareBySurfaceMaterial);
    } else if (strcmp(memberName, "Structural Material") == 0) {
        qsort(Db->picnicTableTable, Db->picnicTableCount, sizeof(PicnicTable), compareByStructuralMaterial);
    } else if (strcmp(memberName, "Neighbourhood ID") == 0) {
        qsort(Db->picnicTableTable, Db->picnicTableCount, sizeof(PicnicTable), compareByNeighbourhoodID);
    } else if (strcmp(memberName, "Neighbourhood Name") == 0) {
        qsort(Db->picnicTableTable, Db->picnicTableCount, sizeof(PicnicTable), compareByNeighbourhoodName);
    } else if (strcmp(memberName, "Ward") == 0) {
        qsort(Db->picnicTableTable, Db->picnicTableCount, sizeof(PicnicTable), compareByWard);
    } else {
        printf("Unknown member name for sorting: %s\n", memberName);
        return;
    }

    // Export to a file named after the member
    char filename[64];
    snprintf(filename, sizeof(filename), "%s.csv", memberName);
    exportDB(filename);

    printf("Sorted database exported to '%s'.\n", filename);
}

//
// compressDB(): 
// Purpose: 
//          compresses the current database into a binary file
// Parameters:
//          filename - name of the output binary file
// Returns: 
//          void
//
void compressDB(char *filename) { 

    FILE *binFile = fopen(filename, "wb");
    
    if (!binFile) {
            perror("Error opening binary File for writing");
            exit(1);

    }

    // Writes the counts and compacities.
    fwrite(&Db -> tableTypeCount, sizeof(int), 1, binFile);
    fwrite(&Db -> surfaceMaterialCount, sizeof(int), 1, binFile);
    fwrite(&Db -> structuralMaterialCount, sizeof(int), 1, binFile);
    fwrite(&Db -> neighbourhoodCount, sizeof(int), 1, binFile);
    fwrite(&Db -> picnicTableCount, sizeof(int), 1, binFile);
    
    // Writes lookup table
    for (int i = 0; i < Db -> tableTypeCount; i++) { 

        fwrite(&Db -> tableTypeTable[i].id, sizeof(int), 1, binFile);
        int len = strlen(Db -> tableTypeTable[i].type) + 1;
        fwrite(&len, sizeof(int), 1, binFile);
        fwrite(Db -> tableTypeTable[i].type, sizeof(char), len, binFile);
    
    }

    //Repeats and writes lookup table for surfaceMaterialTable
    for (int i = 0; i < Db -> surfaceMaterialCount; i++) { 

        fwrite(&Db -> surfaceMaterialTable[i].id, sizeof(int), 1, binFile);
        int len = strlen(Db -> surfaceMaterialTable[i].type) + 1;
        fwrite(&len, sizeof(int), 1, binFile);
        fwrite(Db -> surfaceMaterialTable[i].type, sizeof(char), len, binFile);

    }

    // Repeats and writes lookup table for structuralMaterialCount
    for (int i = 0; i < Db -> structuralMaterialCount; i++) {

        fwrite(&Db -> structuralMaterialTable[i].id, sizeof(int),1, binFile);
        int len = strlen(Db -> structuralMaterialTable[i].type) + 1;
        fwrite(&len, sizeof(int), 1, binFile);
        fwrite(Db -> structuralMaterialTable[i].type, sizeof(char), len, binFile);


    }

    // Writes picnic Table entries.
    for (int i = 0; i < Db -> picnicTableCount; i++) {

        PicnicTable *pt = &Db -> picnicTableTable[i];

        //Write all int fields
        fwrite(&pt -> tableID, sizeof(int), 1, binFile);
        fwrite(&pt -> siteID, sizeof(int), 1, binFile);
        fwrite(&pt -> tableTypeID, sizeof(int), 1, binFile);
        fwrite(&pt -> surfaceMaterialID, sizeof(int), 1, binFile);
        fwrite(&pt -> structuralMaterialID, sizeof(int), 1, binFile);
        fwrite(&pt -> neighbourhoodID, sizeof(int), 1, binFile);

        // Writes all the string fields
        int len = strlen(pt -> streetave) + 1;
        fwrite(&len, sizeof(int), 1, binFile);
        fwrite(pt -> streetave, sizeof(char), len, binFile);
        
        len = strlen(pt -> ward) + 1;
        fwrite(&len, sizeof(int), 1, binFile);
        fwrite(pt -> ward, sizeof(char), 1, binFile);

        len = strlen(pt -> latitude);
        fwrite(&len, sizeof(int), 1, binFile);
        fwrite(pt -> latitude, sizeof(char), len, binFile);

        len = strlen(pt -> longitude)  + 1;
        fwrite(&len, sizeof(int), 1, binFile);
        fwrite(pt -> longitude, sizeof(char), len, binFile);

    }

    fclose(binFile);
    printf("Data base compressed successfully to %s\n", filename);

}

//
// unCompressDB(): 
// Purpose: 
//          loads the database from a binary file into memory
// Parameters: 
//          filename - name of the input binary file 
// Return: 
//          void
//
void unCompressDB(char *filename) {

    FILE *binFile = fopen(filename, "rb");

    if (!binFile) { 

        perror("Error opening binary file for reading");
        exit(1);

    }

    // allocates memory for database 
    Db = malloc(sizeof(DataBase));

    if (!Db) {
        fprintf(stderr, "Memory Allocation failed for database.\n");
        exit(1);
    }

    //Read counts
    fread(&Db -> tableTypeCount, sizeof(int), 1, binFile);
    fread(&Db -> surfaceMaterialCount, sizeof(int), 1, binFile);
    fread(&Db -> structuralMaterialCount, sizeof(int), 1, binFile);
    fread(&Db -> neighbourhoodCount, sizeof(int), 1, binFile);
    fread(&Db -> picnicTableCount, sizeof(int), 1, binFile);

    // Sets the capacities for all same as the count
    Db -> tableTypeCap = Db->tableTypeCount;
    Db -> surfaceMaterialCap = Db->surfaceMaterialCount;
    Db -> structuralMaterialCap = Db->structuralMaterialCount;
    Db -> neighbourhoodCap = Db->neighbourhoodCount;
    Db -> picnicTableCap = Db->picnicTableCount;

    //Allocate memory for tables
    Db->tableTypeTable = malloc(Db->tableTypeCap * sizeof(LookupTable));
    Db->surfaceMaterialTable = malloc(Db->surfaceMaterialCap * sizeof(LookupTable));
    Db->structuralMaterialTable = malloc(Db->structuralMaterialCap * sizeof(LookupTable));
    Db->picnicTableTable = malloc(Db->picnicTableCap * sizeof(PicnicTable));
    Db->neighbourhoodTable = malloc(Db->neighbourhoodCap * sizeof(NeighbourhoodTable)); // Placeholder

    // checks if any db tables failed to allocate memory
    if (!Db -> tableTypeTable || !Db -> surfaceMaterialTable || !Db -> structuralMaterialTable || !Db -> picnicTableTable) { 

        fprintf(stderr, "Memory Allocation failed for DB tables");
        exit(1);

    }

    // REstore table type lookup table from binary
    for (int i = 0; i < Db->tableTypeCount; i++) {
        fread(&Db->tableTypeTable[i].id, sizeof(int), 1, binFile);

        int len;
        fread(&len, sizeof(int), 1, binFile);

        Db->tableTypeTable[i].type = malloc(len);
        fread(Db->tableTypeTable[i].type, sizeof(char), len, binFile);
    }

    // restores surfaceMaterial lookup table
    for (int i = 0; i < Db->surfaceMaterialCount; i++) {
        fread(&Db->surfaceMaterialTable[i].id, sizeof(int), 1, binFile);

        int len;
        fread(&len, sizeof(int), 1, binFile);

        Db->surfaceMaterialTable[i].type = malloc(len);
        fread(Db->surfaceMaterialTable[i].type, sizeof(char), len, binFile);
    }

    // restores structural material lookup table 
    for (int i = 0; i < Db->structuralMaterialCount; i++) {
        fread(&Db->structuralMaterialTable[i].id, sizeof(int), 1, binFile);

        int len;
        fread(&len, sizeof(int), 1, binFile);

        Db->structuralMaterialTable[i].type = malloc(len);
        fread(Db->structuralMaterialTable[i].type, sizeof(char), len, binFile);
    }

    // Loops through all picic table records 
    for (int i = 0; i < Db -> picnicTableCount; i++) { 

        PicnicTable *pt = &Db -> picnicTableTable[i];

        // reads all integer fields for picnic table
        fread(&pt -> tableID, sizeof(int), 1, binFile);
        fread(&pt -> siteID, sizeof(int), 1, binFile);
        fread(&pt -> tableTypeID, sizeof(int), 1, binFile);
        fread(&pt -> surfaceMaterialID, sizeof(int), 1, binFile);
        fread(&pt -> structuralMaterialID, sizeof(int), 1, binFile);
        fread(&pt -> neighbourhoodID, sizeof(int), 1, binFile);

        int len;

        // Reads and stores streetave string
        fread(&len, sizeof(int), 1, binFile);
        pt -> streetave = malloc(len);
        fread(pt -> streetave, sizeof(char), len, binFile);

        // reads and stores ward string
        fread(&len, sizeof(int), 1, binFile);
        pt -> ward = malloc(len);
        fread(pt->ward, sizeof(char), len, binFile);

        // reads and stores latitude string
        fread(&len, sizeof(int), 1, binFile);
        pt->latitude = malloc(len);
        fread(pt->latitude, sizeof(char), len, binFile);

        // reads and stores longitude string
        fread(&len, sizeof(int), 1, binFile);
        pt->longitude = malloc(len);
        fread(pt->longitude, sizeof(char), len, binFile);

    }
    fclose(binFile);
    printf("Database uncompressed succesfully from %s\n", filename);

}
void sortDatabase(int criteria) {
    printf("sortDatabase not yet implemented. Sorting by criteria %d.\n", criteria);
}

/*
 * freeDB
 *  Frees all dynamically allocated memory used in the database.
 *  Should be called before exiting the program.
 */
void freeDB() {
    if (!Db) return; // nothing to free

    // Free all strings in each LookupTable
    for (int i = 0; i < Db->tableTypeCount; i++) {
        free(Db->tableTypeTable[i].type);
    }
    free(Db->tableTypeTable);

    for (int i = 0; i < Db->surfaceMaterialCount; i++) {
        free(Db->surfaceMaterialTable[i].type);
    }
    free(Db->surfaceMaterialTable);

    for (int i = 0; i < Db->structuralMaterialCount; i++) {
        free(Db->structuralMaterialTable[i].type);
    }
    free(Db->structuralMaterialTable);

    // Free neighbourhood table strings
    for (int i = 0; i < Db->neighbourhoodCount; i++) {
        free(Db->neighbourhoodTable[i].name);
    }
    free(Db->neighbourhoodTable);

    // Free strings in picnic table entries
    for (int i = 0; i < Db->picnicTableCount; i++) {
        free(Db->picnicTableTable[i].streetave);
        free(Db->picnicTableTable[i].ward);
        free(Db->picnicTableTable[i].latitude);
        free(Db->picnicTableTable[i].longitude);
    }
    free(Db->picnicTableTable);

    // free the Db struct itself
    free(Db);
    Db = NULL; // set global pointer to NULL for safety
}
