/* DB_impl.h
 *
 * For any "private"  declarations that should not be visible to the public
 * users of the database, but might want to be shared across various source
 * files in database implementation.
 *
 * It is a common convention to append "_impl" to a private implementation of
 * some public interface, so we do so here.
 *
 * Author: <TODO: Group Member Names>
 * Lab instructor: <TODO: Your lab instructor's name here>
 * Lecture instructor: <TODO: Your lecture instructor's name here>
 */


#ifndef DB_IMPL_H
#define DB_IMPL_H

#include "DB.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>


/*
 * You may consider helper functions for the following tasks. Additional helper
 * functions may be needed.
 * - Initialize Db
 * - Look for an item in a LookupTable or NeighbourhoodTable, and return its index
 * - Increase the size of any of the five tables, if capacity is reached.
 * - Print an entry in the format of a line of the .csv file
 * - Count entries for each of the 6 choices in menu option 2
 * - qsort sorting functions for each of the 6 choices in menu option 3
 * - Edit table entry for each of the three choices in menu option 4
 */


// --------------------------------------------------------------------------------------
// Purpose: finds a string in a given lookup table and returns the ID, or inserts string
//          into table, assigning a new ID. 
// Parameters: 
//            table: pointer to the lookup table
//            count: pointer to number of used entries in table
//            cap: pointer to capacity limit
//            value: the string to find or insert. 
// Return: 
//        None
// ---------------------------------------------------------------------------------------
int findOrInsert(LookupTable **table, int *count, int *cap, const char *value);

#endif //DB_IMPL_H
