
/*--------------------------------------------------------------
 # Written by: Abdullah, Abhay, and Essey
 * For: CMPT 201, X02L
 * Lab instructor: Hanan Saleh
 * Lecture instructor: Philip Mees
 * Description:
 *   Main dashboard for user interaction with Picnic Table Database.
 *   Supports importing CSV or binary files, exporting, counting,
 *   sorting, compressing, and exiting.
 * Filename: dashboard.c
 *-------------------------------------------------------------*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "DB.h"

void displayMenu() {
    printf("\n1. Export Database\n");
    printf("2. Count Entries\n");
    printf("3. Sort By\n");
    printf("4. Compress database\n");
    printf("5. Exit\n\n");
}

int main() {
    char filename[256];
    char fileType[8];

    printf("Enter file type (csv or bin): ");
    scanf("%7s", fileType);
    printf("Enter filename: ");
    scanf("%255s", filename);

    if (strcmp(fileType, "csv") == 0) {
        importDB(filename);
    } else if (strcmp(fileType, "bin") == 0) {
        unCompressDB(filename);
    } else {
        printf("Invalid file type. Use 'csv' or 'bin'.\n");
        return 1;
    }

    int option = 0;
    while (1) {
        displayMenu();
        printf("option: ");
        scanf("%d", &option);

        if (option == 1) {
            char outFile[256];
            printf("Enter a filename: ");
            scanf("%255s", outFile);
            exportDB(outFile);
        } else if (option == 2) {
            int code;
            char value[128];
            printf("Enter member code (1.TT 2.SuM 3.StM 4.NID 5.NN 6.W): ");
            scanf("%d", &code);
            printf("Enter Value: ");
            scanf(" %[^]s", value);  // reads full line with spaces
            countEntries(code, value); // implement countEntries()
        } else if (option == 3) {
            int criteria;
            printf("Enter a criteria to sort by (1.TT 2.SuM 3.StM 4.NID 5.NN 6.W): ");
            scanf("%d", &criteria);
            sortDatabase(criteria); //   implement sortDatabase()
        } else if (option == 4) {
            char binOut[256];
            printf("Enter a filename: ");
            scanf("%255s", binOut);
            compressDB(binOut);
        } else if (option == 5) {
            printf("Exiting...\n");
            break;
        } else {
            printf("Invalid option. Try again.\n");
        }
    }

    freeDB(); 
    return 0;
}
