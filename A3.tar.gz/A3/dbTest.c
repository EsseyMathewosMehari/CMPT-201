/* dbTest.c
*
* TODO: Provide a high-level description of what is contained
* in this file.
*
* Author: <TODO: Group Member Names> Abdullah, Essey and Handa 
* Lab instructor: <TODO: Your lab instructor's name here> Hanan Saleh 
* Lecture instructor: <TODO: Your lecture instructor's name here> Philip Mees
*/


#include "DB.h"       /* Import the public database header. */
#include "DB_impl.h"  /* Import the private database header */


int main(void){
   importDB("picnicTableSmall.csv");

   printf("Tables in DB: %d\n", Db->picnicTableCount);

   exportDB("picnicTableSmall.csv");

   //countEntries(membername, value);
   printf("Count by Table Type: %d\n", countEntries("Table Type", "Square Picnic Table"));
   printf("Count by Surface Material: %d\n", countEntries("Surface Material", "Wood"));
   printf("Count by Structural Material : %d\n", countEntries("Structural Material", "Metal"));

   sortByMember("ward"); // generate ward.csv
   sortByMember("Table Type");
   
   compressDB("picnicTableSmall.csv");

   unCompressDB("picnicTableSmall.csv");
   
   freeDB();

   return 0;

}
