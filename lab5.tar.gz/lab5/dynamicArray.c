/*--------------------------------------------------------------
 * Written by: Essey Mehari
 * For: CMPT 201, X02L, Lab Exercise E1
 * Lab instructor: Hanan Saleh
 * Lecture instructor: Philip Mees
 * Description: Implementation of createArray.
 * Filename: dynamicArray.c
 *-------------------------------------------------------------*/
#include "dynamicArray.h"
#include <stdlib.h>

float *createArray(int size, float initialValue)
{
    if (size <= 0)
        return NULL;

    float *arr = malloc(size * sizeof(float));
    if (arr == NULL)
        return NULL;

    for (int i = 0; i < size; i++)
        arr[i] = initialValue;

    return arr;
}
