/*--------------------------------------------------------------
 * Written by: Essey Mehari
 * For: CMPT 201, X02L, Lab Exercise 5 (E2)
 * Lab instructor: Hanan Saleh
 * Lecture instructor: Philip Mees
 * Description: Interface for the Stuff module – dynamic struct
 *              array creation, population, printing, and cleanup.
 * Filename: stuff.h
 *-------------------------------------------------------------*/
#ifndef STUFF_H
#define STUFF_H

#include <stddef.h>   /* size_t */

/*--------------------------------------------------------------
 * Structure definition
 *-------------------------------------------------------------*/
struct stuff {
    char *name;   /* dynamically-allocated string               */
    int  length;  /* length of name (not counting '\0')         */
};

/*--------------------------------------------------------------
 * Function prototypes
 *-------------------------------------------------------------*/

/* Creates an array of <size> struct stuff elements.
 * Returns pointer to the array or NULL on error / size ≤ 0.     */
struct stuff *makeArray(int size);

/* Populates one struct stuff with <data>.
 * Allocates memory for the string and stores its length.        */
void makeStuff(struct stuff *entry, char *data);

/* Prints one struct stuff (string, length) to stdout.           */
void printStuff(struct stuff *entry);

/* Frees every name string in the array and then the array
 * itself.  Safe to call with size ≤ 0 or NULL pointer.          */
void freeStuff(int size, struct stuff *myArray);

#endif /* STUFF_H */
