/*--------------------------------------------------------------
 * Written by: Essey Mehari
 * For: CMPT 201, X02L, Lab Exercise E1
 * Lab instructor: Hanan Saleh
 * Lecture instructor: Philip Mees
 * Description: Interface for createArray dynamically allocates
 *  and initialises a float array.
 * Filename: dynamicArray.h
 *-------------------------------------------------------------*/

#ifndef DYNAMIC_ARRAY_H
#define DYNAMIC_ARRAY_H

/*  Allocates an array of <size> floats, each initialised to
 *  <initialValue>. 
 Returns:
 *    - pointer to the first element on success
 *    - NULL if size ≤ 0 or allocation fails
*/
float *createArray(int size, float initialValue);

#endif 
