/*--------------------------------------------------------------
 * Written by: Essey Mehari
 * For: CMPT 201, X02L, Lab Exercise 5 (E2)
 * Description: Implementation of Stuff module.
 * Filename: stuff.c
 *-------------------------------------------------------------*/
#include "stuff.h"
#include <stdlib.h>   /* malloc, free */
#include <string.h>   /* strlen, strcpy */
#include <stdio.h>

/*--------------------------------------------------------------*/
struct stuff *makeArray(int size)
{
    if (size <= 0)
        return NULL;

    return malloc(size * sizeof(struct stuff));
}

/*--------------------------------------------------------------*/
void makeStuff(struct stuff *entry, char *data)
{
    if (entry == NULL || data == NULL)
        return;

    size_t len = strlen(data);

    /* allocate memory for the string (+1 for '\0') */
    entry->name = malloc(len + 1);
    if (entry->name == NULL)
        return;

    strcpy(entry->name, data);
    entry->length = (int)len;
}

/*--------------------------------------------------------------*/
void printStuff(struct stuff *entry)
{
    if (entry == NULL || entry->name == NULL)
        return;

    printf("Name: %s, Length: %d\n", entry->name, entry->length);
}

/*--------------------------------------------------------------*/
void freeStuff(int size, struct stuff *myArray)
{
    if (size <= 0 || myArray == NULL)
        return;

    for (int i = 0; i < size; i++)
        free(myArray[i].name);

    free(myArray);
}
