/*--------------------------------------------------------------
 * Written by: Essey Mehari
 * For: CMPT 201, X02L, Lab Exercise E1
 * Lab instructor: Hanan Saleh
 * Lecture instructor: Philip Mees
 * Description: Tests createArray – allocates, prints, and frees
 *  a 10-element float array.
 * Filename: 1ab5E1.c
 *-------------------------------------------------------------*/
#include <stdio.h>
#include <stdlib.h>        /* free */
#include "dynamicArray.h"

int main(void)
{
    const int   SIZE  = 10;   /* hard coded*/
    const float INIT  = 3.14f;

    float *array = createArray(SIZE, INIT);
    if (array == NULL) {
        fprintf(stderr, "Error: could not allocate array.\n");
        return 1;
    }

    /* Print elements one per line */
    for (int i = 0; i < SIZE; i++)
        printf("array[%d] = %.2f\n", i, array[i]);

    free(array);/*freeing*/
    return 0;
}
