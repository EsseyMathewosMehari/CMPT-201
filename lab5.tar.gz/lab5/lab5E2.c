/*--------------------------------------------------------------
 * Written by: Essey Mehari
 * For: CMPT 201, X02L, Lab Exercise 5 (E2)
 * Description: Tests Stuff module – builds/prints/frees an
 *              array of four names.
 * Filename: 1ab5E2.c
 *-------------------------------------------------------------*/
#include "stuff.h"
#include <stdio.h>

int main(void)
{
    const int SIZE = 4;

    struct stuff *people = makeArray(SIZE);
    if (people == NULL) {
        fprintf(stderr, "Error: could not allocate Stuff array.\n");
        return 1;
    }

    /* hard-coded names*/
    makeStuff(&people[0], "Hanan");
    makeStuff(&people[1], "Philip");
    makeStuff(&people[2], "Mohammed");
    makeStuff(&people[3], "Essey");

    /* print all entries */
    for (int i = 0; i < SIZE; i++)
        printStuff(&people[i]);

    freeStuff(SIZE, people);
    return 0;
}
